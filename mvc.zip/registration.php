<?php
session_start();
require_once 'RegistrationController.php';

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "my_app";

// Create a database connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    $_SESSION['dbConnected'] = "Connection failed: " . mysqli_connect_error();
    header("Location: registration.php");
    exit;
} else {
    $_SESSION['dbConnected'] = "Connected successfully";
}

// Handle actions
$action = $_GET['action'] ?? '';

if ($action === 'register') {
    $controller = new RegistrationController($conn);
    $controller->registrationAction();
} else {
    displayForm();
}

// Function to display the registration form
function displayForm() {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Registration</title>
    </head>
    <body>
        <fieldset>
            <legend>Registration</legend>
 <form action="index.php?action=register" method="post" novalidate>
 <label for="username">Username</label>
<input type="text" name="username" id="username" required>
                <?php if (isset($_SESSION['usernameErr'])): ?>
                    <span style="color:red;"><?php echo $_SESSION['usernameErr']; ?></span>
                <?php endif; ?>
                <br><br>

                <label for="password">Password</label>
                <input type="password" name="password" id="password" required>
                <?php if (isset($_SESSION['passwordErr'])): ?>
                    <span style="color:red;"><?php echo $_SESSION['passwordErr']; ?></span>
                <?php endif; ?>
                <br><br>

                <input type="submit" value="Register">
            </form>
        </fieldset>
        <?php if (isset($_SESSION['msg'])): ?>
            <p><?php echo $_SESSION['msg']; ?></p>
        <?php endif; ?>
    </body>
    </html>
    <?php
    // Clear session error messages
    $_SESSION['usernameErr'] = "";
    $_SESSION['passwordErr'] = "";
    $_SESSION['msg'] = "";
}
?>