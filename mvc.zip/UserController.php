<?php

require_once 'model/UserModel.php';

class UserController {
    private $userModel;

    public function __construct($conn) {
        $this->userModel = new UserModel($conn);
    }

    public function login($username, $password) {
        $user = $this->userModel->getUserByUsername($username);

        if ($user && password_verify($password, $user['password'])) {
            session_start();
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            header("Location: view/dashboard.php");
        } else {
            $_SESSION['login_error'] = "Invalid username or password";
            header("Location: view/login.php");
        }
    }

    public function register($username, $password) {
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $this->userModel->addUser($username, $hashedPassword);
        $_SESSION['register_success'] = "Account created successfully";
        header("Location: view/login.php");
    }
}
?>
